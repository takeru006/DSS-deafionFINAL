@extends('layouts.app')

@section('content')

<h1>Listado de Tareas</h1>

@if(session('success'))

    <div class="alert alert-success">
        {{ session('success') }}
    </div>

@endif

<a href="{{ route('tareas.create') }}"
   class="btn btn-primary mb-3">

   Nueva Tarea

</a>
<a href="/"
   class="btn btn-secondary mb-3">

   Inicio

</a>
<table class="table table-bordered">

    <thead>

        <tr>

            <th>ID</th>
            <th>Título</th>
            <th>Clase</th>
            <th>Fecha</th>
            <th>Estado</th>
            <th>Acciones</th>

        </tr>

    </thead>

    <tbody>

    @forelse($tareas as $tarea)

        <tr>

            <td>{{ $tarea->id }}</td>

            <td>{{ $tarea->titulo }}</td>

            <td>{{ $tarea->clase->nombre }}</td>

            <td>{{ $tarea->fecha_entrega }}</td>

            <td>{{ $tarea->estado }}</td>

            <td>

                <a href="{{ route('tareas.show', $tarea) }}"
                   class="btn btn-info btn-sm">

                   Ver

                </a>

                <a href="{{ route('tareas.edit', $tarea) }}"
                   class="btn btn-warning btn-sm">

                   Editar

                </a>

                <form action="{{ route('tareas.destroy', $tarea) }}"
                      method="POST"
                      class="d-inline">

                    @csrf
                    @method('DELETE')

                  <button class="btn btn-danger btn-sm"
        onclick="return confirm('¿Deseas eliminar este registro?')">

    Eliminar

</button>
                </form>

            </td>

        </tr>

    @empty

        <tr>

            <td colspan="6">

                No hay tareas

            </td>

        </tr>

    @endforelse

    </tbody>

</table>

@endsection