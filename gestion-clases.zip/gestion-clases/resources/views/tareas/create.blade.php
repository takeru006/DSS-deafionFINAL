@extends('layouts.app')

@section('content')

<h1>Nueva Tarea</h1>
@if ($errors->any())

    <div class="alert alert-danger">

        <ul>

            @foreach ($errors->all() as $error)

                <li>{{ $error }}</li>

            @endforeach

        </ul>

    </div>

@endif

<form action="{{ route('tareas.store') }}"
      method="POST">

    @csrf

    <div class="mb-3">

        <label>Clase</label>

        <select name="clase_id"
                class="form-control">

            @foreach($clases as $clase)

                <option value="{{ $clase->id }}">

                    {{ $clase->nombre }}

                </option>

            @endforeach

        </select>

    </div>

    <div class="mb-3">

        <label>Título</label>

        <input type="text"
               name="titulo"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control"></textarea>

    </div>

    <div class="mb-3">

        <label>Fecha Entrega</label>

        <input type="date"
               name="fecha_entrega"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Estado</label>

        <select name="estado"
                class="form-control">

            <option value="Pendiente">
                Pendiente
            </option>

            <option value="Entregada">
                Entregada
            </option>

            <option value="Vencida">
                Vencida
            </option>

        </select>

    </div>

    <button class="btn btn-success">

        Guardar

    </button>
<a href="{{ route('tareas.index') }}"
   class="btn btn-secondary">

   Regresar

</a>
</form>

@endsection