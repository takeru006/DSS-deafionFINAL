@extends('layouts.app')

@section('content')

<h1>Detalle de Tarea</h1>

<div class="card">

    <div class="card-body">

        <h3>{{ $tarea->titulo }}</h3>

        <hr>

        <p>

            <strong>Clase:</strong>

            {{ $tarea->clase->nombre }}

        </p>

        <p>

            <strong>Descripción:</strong>

            {{ $tarea->descripcion }}

        </p>

        <p>

            <strong>Fecha Entrega:</strong>

            {{ $tarea->fecha_entrega }}

        </p>

        <p>

            <strong>Estado:</strong>

            {{ $tarea->estado }}

        </p>

        <a href="{{ route('tareas.index') }}"
           class="btn btn-secondary">

           Volver

        </a>

    </div>

</div>

@endsection