@extends('layouts.app')

@section('content')

<h1>Editar Tarea</h1>
@if ($errors->any())

    <div class="alert alert-danger">

        <ul>

            @foreach ($errors->all() as $error)

                <li>{{ $error }}</li>

            @endforeach

        </ul>

    </div>

@endif

<form action="{{ route('tareas.update', $tarea) }}"
      method="POST">

    @csrf
    @method('PUT')

    <div class="mb-3">

        <label>Clase</label>

        <select name="clase_id"
                class="form-control">

            @foreach($clases as $clase)

                <option value="{{ $clase->id }}"
                    {{ $tarea->clase_id == $clase->id ? 'selected' : '' }}>

                    {{ $clase->nombre }}

                </option>

            @endforeach

        </select>

    </div>

    <div class="mb-3">

        <label>Título</label>

        <input type="text"
               name="titulo"
               value="{{ $tarea->titulo }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control">{{ $tarea->descripcion }}</textarea>

    </div>

    <div class="mb-3">

        <label>Fecha Entrega</label>

        <input type="date"
               name="fecha_entrega"
               value="{{ $tarea->fecha_entrega }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Estado</label>

        <select name="estado"
                class="form-control">

            <option value="Pendiente"
                {{ $tarea->estado == 'Pendiente' ? 'selected' : '' }}>

                Pendiente

            </option>

            <option value="Entregada"
                {{ $tarea->estado == 'Entregada' ? 'selected' : '' }}>

                Entregada

            </option>

            <option value="Vencida"
                {{ $tarea->estado == 'Vencida' ? 'selected' : '' }}>

                Vencida

            </option>

        </select>

    </div>

    <button class="btn btn-warning">

        Actualizar

    </button>
<a href="{{ route('tareas.index') }}"
   class="btn btn-secondary">

   Regresar

</a>
</form>

@endsection