@extends('layouts.app')

@section('content')

<h1>Listado de Clases</h1>

@if(session('success'))

    <div class="alert alert-success">

        {{ session('success') }}

    </div>

@endif

<a href="{{ route('clases.create') }}"
   class="btn btn-primary mb-3">

    Nueva Clase

</a>

<a href="/"
   class="btn btn-secondary mb-3">

   Inicio

</a>

<table class="table table-hover shadow-sm rounded">
    <thead class="table-primary">

        <tr>

            <th>ID</th>
            <th>Nombre</th>
            <th>Código</th>
            <th>Docente</th>
            <th>Tareas</th>
            <th>Acciones</th>

        </tr>

    </thead>

    <tbody>

    @forelse($clases as $clase)

        <tr>

            <td>{{ $clase->id }}</td>

            <td>{{ $clase->nombre }}</td>

            <td>{{ $clase->codigo }}</td>

            <td>{{ $clase->docente }}</td>

            <td>

                {{ $clase->tareas->count() }}

            </td>

            <td>

                <a href="{{ route('clases.show', $clase) }}"
                   class="btn btn-info btn-sm">

                   Ver

                </a>

                <a href="{{ route('clases.edit', $clase) }}"
                   class="btn btn-warning btn-sm">

                   Editar

                </a>

                <form action="{{ route('clases.destroy', $clase) }}"
                      method="POST"
                      class="d-inline">

                    @csrf
                    @method('DELETE')

                    <button class="btn btn-danger btn-sm"
                            onclick="return confirm('¿Deseas eliminar este registro?')">

                        Eliminar

                    </button>

                </form>

            </td>

        </tr>

    @empty

        <tr>

            <td colspan="6">

                No hay clases registradas

            </td>

        </tr>

    @endforelse

    </tbody>

</table>

@endsection