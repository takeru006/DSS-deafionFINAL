@extends('layouts.app')

@section('content')

<h1>Detalle de Clase</h1>

<div class="card">

    <div class="card-body">

        <h3>{{ $clase->nombre }}</h3>

        <hr>

        <p>
            <strong>Código:</strong>
            {{ $clase->codigo }}
        </p>

        <p>
            <strong>Descripción:</strong>
            {{ $clase->descripcion }}
        </p>

        <p>
            <strong>Horario:</strong>
            {{ $clase->horario }}
        </p>

        <p>
            <strong>Docente:</strong>
            {{ $clase->docente }}
        </p>
<hr>

<h4>Tareas de esta clase</h4>

<ul>

    @forelse($clase->tareas as $tarea)

        <li>

            {{ $tarea->titulo }}

        </li>

    @empty

        <li>

            No hay tareas registradas.

        </li>

    @endforelse

</ul>
        <a href="{{ route('clases.index') }}"
           class="btn btn-secondary">

           Volver

        </a>

    </div>

</div>

@endsection