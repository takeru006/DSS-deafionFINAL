@extends('layouts.app')

@section('content')

<h1>Editar Clase</h1>

@if ($errors->any())

    <div class="alert alert-danger">

        <ul>

            @foreach ($errors->all() as $error)

                <li>{{ $error }}</li>

            @endforeach

        </ul>

    </div>

@endif

<form action="{{ route('clases.update', $clase) }}"
      method="POST">

    @csrf
    @method('PUT')

    <div class="mb-3">

        <label>Nombre</label>

        <input type="text"
               name="nombre"
               value="{{ $clase->nombre }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Código</label>

        <input type="text"
               name="codigo"
               value="{{ $clase->codigo }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control">{{ $clase->descripcion }}</textarea>

    </div>

    <div class="mb-3">

        <label>Horario</label>

        <input type="text"
               name="horario"
               value="{{ $clase->horario }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Docente</label>

        <input type="text"
               name="docente"
               value="{{ $clase->docente }}"
               class="form-control">

    </div>

    <button class="btn btn-warning">
        Actualizar
    </button>
<a href="{{ route('clases.index') }}"
   class="btn btn-secondary">

   Regresar

</a>
</form>

@endsection