@extends('layouts.app')

@section('content')

<h1>Nuevo Estudiante</h1>
@if ($errors->any())

    <div class="alert alert-danger">

        <ul>

            @foreach ($errors->all() as $error)

                <li>{{ $error }}</li>

            @endforeach

        </ul>

    </div>

@endif

<form action="{{ route('estudiantes.store') }}"
      method="POST">

    @csrf

    <div class="mb-3">

        <label>Nombre</label>

        <input type="text"
               name="nombre"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Correo</label>

        <input type="email"
               name="correo"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Carnet</label>

        <input type="text"
               name="carnet"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Carrera</label>

        <input type="text"
               name="carrera"
               class="form-control">

    </div>

    <button class="btn btn-success">

        Guardar

    </button>
<a href="{{ route('estudiantes.index') }}"
   class="btn btn-secondary">

   Regresar

</a>
</form>

@endsection