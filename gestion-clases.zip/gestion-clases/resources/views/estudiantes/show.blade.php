@extends('layouts.app')

@section('content')

<h1>Detalle de Estudiante</h1>

<div class="card">

    <div class="card-body">

        <h3>{{ $estudiante->nombre }}</h3>

        <hr>

        <p>

            <strong>Correo:</strong>

            {{ $estudiante->correo }}

        </p>

        <p>

            <strong>Carnet:</strong>

            {{ $estudiante->carnet }}

        </p>

        <p>

            <strong>Carrera:</strong>

            {{ $estudiante->carrera }}

        </p>

        <a href="{{ route('estudiantes.index') }}"
           class="btn btn-secondary">

           Volver

        </a>

    </div>

</div>

@endsection