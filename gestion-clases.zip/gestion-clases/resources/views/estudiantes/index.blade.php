@extends('layouts.app')

@section('content')

<h1>Listado de Estudiantes</h1>

@if(session('success'))

    <div class="alert alert-success">

        {{ session('success') }}

    </div>

@endif

<a href="{{ route('estudiantes.create') }}"
   class="btn btn-primary mb-3">

   Nuevo Estudiante

</a>
<a href="/"
   class="btn btn-secondary mb-3">

   Inicio

</a>
<table class="table table-bordered">

    <thead>

        <tr>

            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Carnet</th>
            <th>Carrera</th>
            <th>Acciones</th>

        </tr>

    </thead>

    <tbody>

    @forelse($estudiantes as $estudiante)

        <tr>

            <td>{{ $estudiante->id }}</td>

            <td>{{ $estudiante->nombre }}</td>

            <td>{{ $estudiante->correo }}</td>

            <td>{{ $estudiante->carnet }}</td>

            <td>{{ $estudiante->carrera }}</td>

            <td>

                <a href="{{ route('estudiantes.show', $estudiante) }}"
                   class="btn btn-info btn-sm">

                   Ver

                </a>

                <a href="{{ route('estudiantes.edit', $estudiante) }}"
                   class="btn btn-warning btn-sm">

                   Editar

                </a>

                <form action="{{ route('estudiantes.destroy', $estudiante) }}"
                      method="POST"
                      class="d-inline">

                    @csrf
                    @method('DELETE')

                    <button class="btn btn-danger btn-sm"
        onclick="return confirm('¿Deseas eliminar este registro?')">

    Eliminar

</button>

                </form>

            </td>

        </tr>

    @empty

        <tr>

            <td colspan="6">

                No hay estudiantes

            </td>

        </tr>

    @endforelse

    </tbody>

</table>

@endsection