@extends('layouts.app')

@section('content')

<h1>Editar Estudiante</h1>
@if ($errors->any())

    <div class="alert alert-danger">

        <ul>

            @foreach ($errors->all() as $error)

                <li>{{ $error }}</li>

            @endforeach

        </ul>

    </div>

@endif
<form action="{{ route('estudiantes.update', $estudiante) }}"
      method="POST">

    @csrf
    @method('PUT')

    <div class="mb-3">

        <label>Nombre</label>

        <input type="text"
               name="nombre"
               value="{{ $estudiante->nombre }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Correo</label>

        <input type="email"
               name="correo"
               value="{{ $estudiante->correo }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Carnet</label>

        <input type="text"
               name="carnet"
               value="{{ $estudiante->carnet }}"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Carrera</label>

        <input type="text"
               name="carrera"
               value="{{ $estudiante->carrera }}"
               class="form-control">

    </div>

    <button class="btn btn-warning">

        Actualizar

    </button>
<a href="{{ route('estudiantes.index') }}"
   class="btn btn-secondary">

   Regresar

</a>
</form>

@endsection