@extends('layouts.app')

@section('content')

<div class="text-center mb-4">

    <h1>📘 Sistema de Gestión Académica</h1>

    <p class="text-muted">
        Control de clases, tareas y estudiantes
    </p>

</div>

<div class="row g-4">

    <div class="col-md-4">
        <div class="card p-4 text-center">
            <h2>📚</h2>
            <h4>Clases</h4>
            <a href="{{ route('clases.index') }}" class="btn btn-primary mt-2">Entrar</a>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-4 text-center">
            <h2>📝</h2>
            <h4>Tareas</h4>
            <a href="{{ route('tareas.index') }}" class="btn btn-success mt-2">Entrar</a>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-4 text-center">
            <h2>🎓</h2>
            <h4>Estudiantes</h4>
            <a href="{{ route('estudiantes.index') }}" class="btn btn-warning mt-2">Entrar</a>
        </div>
    </div>

</div>

@endsection