<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión Académica</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilo personalizado -->
    <style>
        body {
            background: #f4f6f9;
        }

        .navbar {
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        }

        .btn {
            border-radius: 10px;
        }

        table {
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }

        h1 {
            font-weight: 700;
        }
    </style>

</head>

<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/">
            🎓 Sistema Académico
        </a>

        <div>
            <a href="{{ route('clases.index') }}" class="btn btn-light btn-sm me-2">Clases</a>
            <a href="{{ route('tareas.index') }}" class="btn btn-light btn-sm me-2">Tareas</a>
            <a href="{{ route('estudiantes.index') }}" class="btn btn-light btn-sm">Estudiantes</a>
        </div>
    </div>
</nav>

<div class="container py-4">

    @yield('content')

</div>

</body>
</html>