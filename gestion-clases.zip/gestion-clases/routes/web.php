<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClaseController;
use App\Http\Controllers\TareaController;
use App\Http\Controllers\EstudianteController;

Route::get('/', function () {
    return view('welcome');
});

Route::resource('clases', ClaseController::class);
Route::resource('tareas', TareaController::class);
Route::resource('estudiantes', EstudianteController::class);