<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTareaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [

            'clase_id' => 'required',

            'titulo' => 'required|max:100',

            'descripcion' => 'required',

            'fecha_entrega' => 'required|date',

            'estado' => 'required'

        ];
    }
}