<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreClaseRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'nombre' => 'required|max:100',

            'codigo' => 'required|unique:clases|max:50',

            'descripcion' => 'required',

            'horario' => 'required|max:100',

            'docente' => 'required|max:100'
        ];
    }
}