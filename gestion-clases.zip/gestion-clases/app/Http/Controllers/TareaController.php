<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tarea;
use App\Models\Clase;
use App\Http\Requests\StoreTareaRequest;
use App\Http\Requests\UpdateTareaRequest;


class TareaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
   public function index()
{
    $tareas = Tarea::with('clase')->get();

    return view('tareas.index', compact('tareas'));
}

    /**
     * Show the form for creating a new resource.
     */
  public function create()
{
    $clases = Clase::all();

    return view('tareas.create', compact('clases'));
}
    /**
     * Store a newly created resource in storage.
     */
public function store(StoreTareaRequest $request)
{
    Tarea::create($request->all());

    return redirect()->route('tareas.index')
                     ->with('success', 'Tarea creada');
}

    /**
     * Display the specified resource.
     */
 public function show(Tarea $tarea)
{
    return view('tareas.show', compact('tarea'));
}

    /**
     * Show the form for editing the specified resource.
     */
 public function edit(Tarea $tarea)
{
    $clases = Clase::all();

    return view('tareas.edit', compact('tarea', 'clases'));
}

    /**
     * Update the specified resource in storage.
     */
 public function update(UpdateTareaRequest $request, Tarea $tarea)
{
    $tarea->update($request->all());

    return redirect()->route('tareas.index')
                     ->with('success', 'Tarea actualizada');
}

    /**
     * Remove the specified resource from storage.
     */
  public function destroy(Tarea $tarea)
{
    $tarea->delete();

    return redirect()->route('tareas.index')
                     ->with('success', 'Tarea eliminada');
}
}
