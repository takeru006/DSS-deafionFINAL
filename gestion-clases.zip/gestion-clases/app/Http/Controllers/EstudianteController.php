<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreEstudianteRequest;
use App\Http\Requests\UpdateEstudianteRequest;
use Illuminate\Http\Request;
use App\Models\Estudiante;
class EstudianteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
   public function index()
{
    $estudiantes = Estudiante::all();

    return view('estudiantes.index', compact('estudiantes'));
}

public function create()
{
    return view('estudiantes.create');
}

public function store(StoreEstudianteRequest $request)
{
    Estudiante::create($request->all());

    return redirect()->route('estudiantes.index')
                     ->with('success', 'Estudiante creado');
}

public function show(Estudiante $estudiante)
{
    return view('estudiantes.show', compact('estudiante'));
}

public function edit(Estudiante $estudiante)
{
    return view('estudiantes.edit', compact('estudiante'));
}

public function update(UpdateEstudianteRequest $request, Estudiante $estudiante)
{
    $estudiante->update($request->all());

    return redirect()->route('estudiantes.index')
                     ->with('success', 'Estudiante actualizado');
}

public function destroy(Estudiante $estudiante)
{
    $estudiante->delete();

    return redirect()->route('estudiantes.index')
                     ->with('success', 'Estudiante eliminado');
}
}
