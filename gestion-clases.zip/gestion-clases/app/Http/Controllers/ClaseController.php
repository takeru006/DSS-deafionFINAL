<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Clase;
use App\Http\Requests\StoreClaseRequest;
use App\Http\Requests\UpdateClaseRequest;

class ClaseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
   public function index()
{
    $clases = Clase::all();

    return view('clases.index', compact('clases'));
}
    /**
     * Show the form for creating a new resource.
     */
public function create()
{
    return view('clases.create');
}

    /**
     * Store a newly created resource in storage.
     */
  public function store(Request $request)
{
    Clase::create($request->all());

    return redirect()->route('clases.index')
                     ->with('success', 'Clase creada correctamente');
}

    /**
     * Display the specified resource.
     */
   public function show(Clase $clase)
{
    return view('clases.show', compact('clase'));
}

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Clase $clase)
{
    return view('clases.edit', compact('clase'));
}

    /**
     * Update the specified resource in storage.
     */
   public function update(UpdateClaseRequest $request, Clase $clase)
{
    $clase->update($request->all());

    return redirect()->route('clases.index')
                     ->with('success', 'Clase actualizada');
}
    /**
     * Remove the specified resource from storage.
     */
   public function destroy(Clase $clase)
{
    $clase->delete();

    return redirect()->route('clases.index')
                     ->with('success', 'Clase eliminada');
}
}
