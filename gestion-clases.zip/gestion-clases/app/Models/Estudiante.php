<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Estudiante extends Model
{
    protected $fillable = [
        'nombre',
        'correo',
        'carnet',
        'carrera'
    ];

    public function clases()
    {
        return $this->belongsToMany(Clase::class);
    }
}