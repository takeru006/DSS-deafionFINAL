<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Tarea;

class Clase extends Model
{
    protected $fillable = [
        'nombre',
        'codigo',
        'descripcion',
        'horario',
        'docente'
    ];

    public function tareas()
    {
        return $this->hasMany(Tarea::class);
    }

    public function estudiantes()
    {
        return $this->belongsToMany(Estudiante::class);
    }
}