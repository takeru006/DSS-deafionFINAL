<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tarea extends Model
{
    protected $fillable = [
        'clase_id',
        'titulo',
        'descripcion',
        'fecha_entrega',
        'estado'
    ];

    public function clase()
    {
        return $this->belongsTo(Clase::class);
    }
}