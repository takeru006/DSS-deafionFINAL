

<?php $__env->startSection('content'); ?>

<h1>Editar Clase</h1>

<?php if($errors->any()): ?>

    <div class="alert alert-danger">

        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>

<?php endif; ?>

<form action="<?php echo e(route('clases.update', $clase)); ?>"
      method="POST">

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">

        <label>Nombre</label>

        <input type="text"
               name="nombre"
               value="<?php echo e($clase->nombre); ?>"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Código</label>

        <input type="text"
               name="codigo"
               value="<?php echo e($clase->codigo); ?>"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control"><?php echo e($clase->descripcion); ?></textarea>

    </div>

    <div class="mb-3">

        <label>Horario</label>

        <input type="text"
               name="horario"
               value="<?php echo e($clase->horario); ?>"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Docente</label>

        <input type="text"
               name="docente"
               value="<?php echo e($clase->docente); ?>"
               class="form-control">

    </div>

    <button class="btn btn-warning">
        Actualizar
    </button>
<a href="<?php echo e(route('clases.index')); ?>"
   class="btn btn-secondary">

   Regresar

</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/clases/edit.blade.php ENDPATH**/ ?>