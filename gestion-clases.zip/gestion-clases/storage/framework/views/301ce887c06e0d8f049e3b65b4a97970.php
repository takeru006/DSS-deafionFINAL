

<?php $__env->startSection('content'); ?>

<h1>Nueva Tarea</h1>

<form action="<?php echo e(route('tareas.store')); ?>"
      method="POST">

    <?php echo csrf_field(); ?>

    <div class="mb-3">

        <label>Clase</label>

        <select name="clase_id"
                class="form-control">

            <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($clase->id); ?>">

                    <?php echo e($clase->nombre); ?>


                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

    </div>

    <div class="mb-3">

        <label>Título</label>

        <input type="text"
               name="titulo"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control"></textarea>

    </div>

    <div class="mb-3">

        <label>Fecha Entrega</label>

        <input type="date"
               name="fecha_entrega"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Estado</label>

        <select name="estado"
                class="form-control">

            <option value="Pendiente">
                Pendiente
            </option>

            <option value="Entregada">
                Entregada
            </option>

            <option value="Vencida">
                Vencida
            </option>

        </select>

    </div>

    <button class="btn btn-success">

        Guardar

    </button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/tareas/create.blade.php ENDPATH**/ ?>