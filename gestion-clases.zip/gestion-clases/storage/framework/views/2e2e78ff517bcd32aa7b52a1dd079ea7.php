

<?php $__env->startSection('content'); ?>

<h1>Editar Tarea</h1>

<form action="<?php echo e(route('tareas.update', $tarea)); ?>"
      method="POST">

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">

        <label>Clase</label>

        <select name="clase_id"
                class="form-control">

            <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e($clase->id); ?>"
                    <?php echo e($tarea->clase_id == $clase->id ? 'selected' : ''); ?>>

                    <?php echo e($clase->nombre); ?>


                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

    </div>

    <div class="mb-3">

        <label>Título</label>

        <input type="text"
               name="titulo"
               value="<?php echo e($tarea->titulo); ?>"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control"><?php echo e($tarea->descripcion); ?></textarea>

    </div>

    <div class="mb-3">

        <label>Fecha Entrega</label>

        <input type="date"
               name="fecha_entrega"
               value="<?php echo e($tarea->fecha_entrega); ?>"
               class="form-control">

    </div>

    <div class="mb-3">

        <label>Estado</label>

        <select name="estado"
                class="form-control">

            <option value="Pendiente"
                <?php echo e($tarea->estado == 'Pendiente' ? 'selected' : ''); ?>>

                Pendiente

            </option>

            <option value="Entregada"
                <?php echo e($tarea->estado == 'Entregada' ? 'selected' : ''); ?>>

                Entregada

            </option>

            <option value="Vencida"
                <?php echo e($tarea->estado == 'Vencida' ? 'selected' : ''); ?>>

                Vencida

            </option>

        </select>

    </div>

    <button class="btn btn-warning">

        Actualizar

    </button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/tareas/edit.blade.php ENDPATH**/ ?>