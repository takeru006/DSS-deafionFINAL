<?php $__env->startSection('content'); ?>

<div class="text-center mb-4">

    <h1>📘 Sistema de Gestión Académica</h1>

    <p class="text-muted">
        Control de clases, tareas y estudiantes
    </p>

</div>

<div class="row g-4">

    <div class="col-md-4">
        <div class="card p-4 text-center">
            <h2>📚</h2>
            <h4>Clases</h4>
            <a href="<?php echo e(route('clases.index')); ?>" class="btn btn-primary mt-2">Entrar</a>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-4 text-center">
            <h2>📝</h2>
            <h4>Tareas</h4>
            <a href="<?php echo e(route('tareas.index')); ?>" class="btn btn-success mt-2">Entrar</a>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-4 text-center">
            <h2>🎓</h2>
            <h4>Estudiantes</h4>
            <a href="<?php echo e(route('estudiantes.index')); ?>" class="btn btn-warning mt-2">Entrar</a>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/welcome.blade.php ENDPATH**/ ?>