

<?php $__env->startSection('content'); ?>

<h1>Listado de Estudiantes</h1>

<?php if(session('success')): ?>

    <div class="alert alert-success">

        <?php echo e(session('success')); ?>


    </div>

<?php endif; ?>

<a href="<?php echo e(route('estudiantes.create')); ?>"
   class="btn btn-primary mb-3">

   Nuevo Estudiante

</a>
<a href="/"
   class="btn btn-secondary mb-3">

   Inicio

</a>
<table class="table table-bordered">

    <thead>

        <tr>

            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Carnet</th>
            <th>Carrera</th>
            <th>Acciones</th>

        </tr>

    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

            <td><?php echo e($estudiante->id); ?></td>

            <td><?php echo e($estudiante->nombre); ?></td>

            <td><?php echo e($estudiante->correo); ?></td>

            <td><?php echo e($estudiante->carnet); ?></td>

            <td><?php echo e($estudiante->carrera); ?></td>

            <td>

                <a href="<?php echo e(route('estudiantes.show', $estudiante)); ?>"
                   class="btn btn-info btn-sm">

                   Ver

                </a>

                <a href="<?php echo e(route('estudiantes.edit', $estudiante)); ?>"
                   class="btn btn-warning btn-sm">

                   Editar

                </a>

                <form action="<?php echo e(route('estudiantes.destroy', $estudiante)); ?>"
                      method="POST"
                      class="d-inline">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger btn-sm"
        onclick="return confirm('¿Deseas eliminar este registro?')">

    Eliminar

</button>

                </form>

            </td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>

            <td colspan="6">

                No hay estudiantes

            </td>

        </tr>

    <?php endif; ?>

    </tbody>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/estudiantes/index.blade.php ENDPATH**/ ?>