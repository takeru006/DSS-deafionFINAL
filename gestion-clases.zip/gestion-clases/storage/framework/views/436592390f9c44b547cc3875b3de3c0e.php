

<?php $__env->startSection('content'); ?>

<h1>Detalle de Tarea</h1>

<div class="card">

    <div class="card-body">

        <h3><?php echo e($tarea->titulo); ?></h3>

        <hr>

        <p>

            <strong>Clase:</strong>

            <?php echo e($tarea->clase->nombre); ?>


        </p>

        <p>

            <strong>Descripción:</strong>

            <?php echo e($tarea->descripcion); ?>


        </p>

        <p>

            <strong>Fecha Entrega:</strong>

            <?php echo e($tarea->fecha_entrega); ?>


        </p>

        <p>

            <strong>Estado:</strong>

            <?php echo e($tarea->estado); ?>


        </p>

        <a href="<?php echo e(route('tareas.index')); ?>"
           class="btn btn-secondary">

           Volver

        </a>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/tareas/show.blade.php ENDPATH**/ ?>