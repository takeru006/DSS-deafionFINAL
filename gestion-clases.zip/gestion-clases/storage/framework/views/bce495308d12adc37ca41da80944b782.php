

<?php $__env->startSection('content'); ?>

<h1>Listado de Clases</h1>

<?php if(session('success')): ?>

    <div class="alert alert-success">

        <?php echo e(session('success')); ?>


    </div>

<?php endif; ?>

<a href="<?php echo e(route('clases.create')); ?>"
   class="btn btn-primary mb-3">

    Nueva Clase

</a>

<a href="/"
   class="btn btn-secondary mb-3">

   Inicio

</a>

<table class="table table-hover shadow-sm rounded">
    <thead class="table-primary">

        <tr>

            <th>ID</th>
            <th>Nombre</th>
            <th>Código</th>
            <th>Docente</th>
            <th>Tareas</th>
            <th>Acciones</th>

        </tr>

    </thead>

    <tbody>

    <?php $__empty_1 = true; $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <tr>

            <td><?php echo e($clase->id); ?></td>

            <td><?php echo e($clase->nombre); ?></td>

            <td><?php echo e($clase->codigo); ?></td>

            <td><?php echo e($clase->docente); ?></td>

            <td>

                <?php echo e($clase->tareas->count()); ?>


            </td>

            <td>

                <a href="<?php echo e(route('clases.show', $clase)); ?>"
                   class="btn btn-info btn-sm">

                   Ver

                </a>

                <a href="<?php echo e(route('clases.edit', $clase)); ?>"
                   class="btn btn-warning btn-sm">

                   Editar

                </a>

                <form action="<?php echo e(route('clases.destroy', $clase)); ?>"
                      method="POST"
                      class="d-inline">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger btn-sm"
                            onclick="return confirm('¿Deseas eliminar este registro?')">

                        Eliminar

                    </button>

                </form>

            </td>

        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>

            <td colspan="6">

                No hay clases registradas

            </td>

        </tr>

    <?php endif; ?>

    </tbody>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/clases/index.blade.php ENDPATH**/ ?>