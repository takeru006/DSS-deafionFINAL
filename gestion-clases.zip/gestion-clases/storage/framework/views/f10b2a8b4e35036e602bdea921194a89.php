

<?php $__env->startSection('content'); ?>

<h1>Detalle de Clase</h1>

<div class="card">

    <div class="card-body">

        <h3><?php echo e($clase->nombre); ?></h3>

        <hr>

        <p>
            <strong>Código:</strong>
            <?php echo e($clase->codigo); ?>

        </p>

        <p>
            <strong>Descripción:</strong>
            <?php echo e($clase->descripcion); ?>

        </p>

        <p>
            <strong>Horario:</strong>
            <?php echo e($clase->horario); ?>

        </p>

        <p>
            <strong>Docente:</strong>
            <?php echo e($clase->docente); ?>

        </p>
<hr>

<h4>Tareas de esta clase</h4>

<ul>

    <?php $__empty_1 = true; $__currentLoopData = $clase->tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <li>

            <?php echo e($tarea->titulo); ?>


        </li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <li>

            No hay tareas registradas.

        </li>

    <?php endif; ?>

</ul>
        <a href="<?php echo e(route('clases.index')); ?>"
           class="btn btn-secondary">

           Volver

        </a>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/clases/show.blade.php ENDPATH**/ ?>