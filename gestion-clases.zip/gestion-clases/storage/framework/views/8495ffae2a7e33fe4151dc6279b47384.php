

<?php $__env->startSection('content'); ?>

<h1>Nueva Clase</h1>
<?php if($errors->any()): ?>

    <div class="alert alert-danger">

        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>

<?php endif; ?>

<form action="<?php echo e(route('clases.store')); ?>" method="POST">

    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label>Nombre</label>

        <input type="text"
               name="nombre"
               class="form-control">

    </div>

    <div class="mb-3">
        <label>Código</label>

        <input type="text"
               name="codigo"
               class="form-control">

    </div>

    <div class="mb-3">
        <label>Descripción</label>

        <textarea name="descripcion"
                  class="form-control"></textarea>

    </div>

    <div class="mb-3">
        <label>Horario</label>

        <input type="text"
               name="horario"
               class="form-control">

    </div>

    <div class="mb-3">
        <label>Docente</label>

        <input type="text"
               name="docente"
               class="form-control">

    </div>

    <button class="btn btn-success">
        Guardar
    </button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PÇ GAMER\OneDrive\Escritorio\gestion-clases\resources\views/clases/create.blade.php ENDPATH**/ ?>